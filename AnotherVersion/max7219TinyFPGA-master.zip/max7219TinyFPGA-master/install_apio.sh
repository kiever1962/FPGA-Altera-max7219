pip install apio==0.4.0b3 tinyprog
apio install system scons icestorm drivers
apio drivers --serial-enable

